#include "findpwd.h"
#include "ui_findpwd.h"

findPwd::findPwd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::findPwd)
{
    ui->setupUi(this);
}

findPwd::~findPwd()
{
    delete ui;
}

void findPwd::on_returnBtn_clicked()
{
    this->close();
    emit this->close_findpwd();
}

void findPwd::on_searchBtn_clicked()
{
    if(ui->aswLineE_3->text().isEmpty() || ui->aswLineE_2->text().isEmpty()) {
        QMessageBox::critical(this,"warn","请输入新密码并确认");
        return;
    } else if(ui->aswLineE_3->text().compare(ui->aswLineE_2->text()) != 0) {
        QMessageBox::critical(this,"warn","两次输入密码不一致");
        return;
    } else if(ui->aswLineE->text().isEmpty()) {
        QMessageBox::critical(this,"warn","请输入密保问题答案");
        return;
    }
    //获取页面数据
    this->new_pwd = ui->aswLineE_3->text();
    this->user_que_answer = ui->aswLineE->text();
    this->user_id = ui->userName->text();
    emit findpwd_user();//找回密码
    QMessageBox::critical(this,"info","操作成功，点击确定返回登录界面...");
    emit close_findpwd();//关闭界面
    this->close();
}

void findPwd::pass_userid(QString que)
{
    ui->aswLineE_4->setText(que);
}

void findPwd::on_userBtn_clicked()
{
    if(ui->userName->text().isEmpty()) {
        QMessageBox::critical(this,"info","用户ID不能为空...");
        return;
    }
    QString user = ui->userName->text();
    emit getUerid(user);
}
