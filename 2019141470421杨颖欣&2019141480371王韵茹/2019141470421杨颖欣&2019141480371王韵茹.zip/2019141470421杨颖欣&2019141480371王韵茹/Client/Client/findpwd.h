#ifndef FINDPWD_H
#define FINDPWD_H

#include <QWidget>
#include <QMessageBox>

namespace Ui {
class findPwd;
}

class findPwd : public QWidget
{
    Q_OBJECT

public:
    explicit findPwd(QWidget *parent = nullptr);
    ~findPwd();
    QString user_que_answer;//密保答案
    QString user_id;//用户id
    QString new_pwd;//新密码

signals:
    void close_findpwd();//关闭
    void findpwd_user();//找回密码
    void getUerid(QString);//获取用户id

private slots:
    void pass_userid(QString);//验证用户id

    void on_returnBtn_clicked();//返回上个界面
    void on_searchBtn_clicked();//查询用户密保问题
    void on_userBtn_clicked();//查询用户

private:
    Ui::findPwd *ui;
};

#endif // FINDPWD_H
