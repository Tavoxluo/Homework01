#include "login.h"
#include "ui_login.h"

#include <QDebug>
#include <QMessageBox>
#include <QFile>

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    //global_login = this;
    mainwindow = new class mainwindow();
    regist = new class regist();
    findpwd = new class findPwd();
    records = new class records();

    /* 连接数据库 */
    db = QSqlDatabase::addDatabase("QODBC");
    db.setHostName("127.0.0.1");
    db.setPort(3306);
    db.setDatabaseName("chatTest");
    db.setUserName("root");
    db.setPassword("1233211234567");
    bool dbok = db.open();
    if(!dbok){
        QMessageBox::critical(this,"错误","数据库未启动");
    }
    //连接test数据库
    result = db.exec("use test");

    clientsocket = new QTcpSocket();
    serverConnect = false;
    m_icon.setIcon(QIcon(":/media/media/show.png"));
    show_timer = new QTimer(this);
    hide_timer = new QTimer(this);
    timer = new QTimer(this);

    /* 信号槽 */
    connect(mainwindow, SIGNAL(close_main(QString)), this, SLOT(show_login(QString)));
    connect(regist, SIGNAL(close_regist(QString)), this, SLOT(show_login(QString)));


    connect(ui->user, SIGNAL(ui->user->currentTextChanged()), this, SLOT(changeUsername()));
    //connect(ui->user, SIGNAL(ui->user->currentIndexChanged()), this, SLOT(changeUsername()));
    connect(this, SIGNAL(sendChildmsg(QString, QString)), mainwindow, SLOT(acceptParentmsg(QString, QString)));
    connect(mainwindow, SIGNAL(sendMsg(QString)), this, SLOT(forwardMsg(QString)));
    connect(this, SIGNAL(usedb(QStringListModel*, QStringList)), mainwindow, SLOT(getUsers(QStringListModel*, QStringList)));
    connect(mainwindow, SIGNAL(addFriend(QString)), this, SLOT(addFriend(QString)));
    connect(mainwindow->record, SIGNAL(show_record(int, QString)), this, SLOT(show_record(int, QString)));
    connect(this, SIGNAL(show_record_msg(int, QString)), mainwindow->record, SLOT(show_record_msg(int, QString)));
    connect(regist, SIGNAL(back_login()), this, SLOT(back_login()));
    connect(regist, SIGNAL(register_user()), this, SLOT(register_user()));
    connect(findpwd, SIGNAL(close_findpwd()), this, SLOT(back_login()));
    connect(findpwd, SIGNAL(getUerid(QString)), this, SLOT(getUerid(QString)));
    connect(findpwd, SIGNAL(findpwd_user()), this, SLOT(findpwd_user()));
    connect(this, SIGNAL(pass_userid(QString)), findpwd, SLOT(pass_userid(QString)));
    connect(show_timer, SIGNAL(timeout()), this, SLOT(onshowTimeout()));
    connect(hide_timer, SIGNAL(timeout()), this, SLOT(onhideTimeout()));
    connect(timer, SIGNAL(timeout()), this, SLOT(onTimeout()));

    /* 图标显示 */
    m_icon.show();

//    this->show_timer->start(300);
//    this->timer->start(5000);
}

void login::onTimeout()
{
    m_icon.setIcon(QIcon(":/media/media/show.png"));
    //QMessageBox::about(this, "sf", "df");
    this->hide_timer->stop();
    this->show_timer->stop();
}

void login::onhideTimeout()
{
    m_icon.setIcon(QIcon(":/media/media/show.png"));
    //QMessageBox::about(this, "sf", "df");
    this->hide_timer->stop();
    this->show_timer->start(300);
}

void login::onshowTimeout()
{
    m_icon.setIcon(QIcon(":/media/media/hide.png"));
    //QMessageBox::about(this, "sf", "df");
    this->show_timer->stop();
    this->hide_timer->start(300);
}

login::~login()
{
    delete ui;
}

//注册
void login::register_user()
{
    //生成用户id
    QString user_id = this->generate_userid();
    if(user_id.compare("false") == 0){
        QMessageBox::information(this,"错误","用户ID生成失败...");
        return;
    }
    //操作数据库users
    QString sql = "insert into users(user_id,user_name) values('" + user_id + "','" + regist->user_name + "')";
    result.clear();
    bool result_success = result.exec(sql);
    if(!result_success){
        QMessageBox::information(this,"错误","users 操作失败");
        return;
    }
    //操作数据库users_detail
    QString detailSql = "insert into users_detail(user_id,user_pwd,user_pwd_question,user_pwd_answer,user_power,user_state) values('" + user_id + "','" + regist->user_pwd + "','" + regist->user_que + "','" + regist->user_asw + "','01','01')";
    result.clear();
    result_success = result.exec(detailSql);
    if(!result_success){
        QMessageBox::information(this,"错误","user_detail 操纵失败");
        return;
    }
    this->new_userid.clear();
    this->new_userid = user_id;
    QMessageBox::information(regist,"成功", "请记住用户ID以登录！\n" + user_id);
}

//获取密保问题
void login::getUerid(QString user_id)
{
    QString que;
    QString sql = "select user_pwd_question as que from users_detail where user_id='" + user_id + "'";
    result.clear();
    result = db.exec(sql);
    while(result.next()){
        que = result.value("que").toString();
    }
    if(que.isEmpty()) {
        QMessageBox::about(findpwd, "error", "用户ID出错...");
        return;
    }
    /* 传递密保问题 密保答案 */
    emit pass_userid(que);
}

//修改密码保存
void login::findpwd_user()
{
    QString sql="select user_id from users_detail where user_id='" + findpwd->user_id + "' and user_pwd_answer='" + findpwd->user_que_answer + "'";

    //操作数据库
    result.clear();
    result = db.exec(sql);
    while(!result.next()){
        QMessageBox::information(this,"错误","密保答案错误");
        return;
    }

    //保存新密码
    result.clear();
    QString insertSql = "update users_detail set user_pwd='" + findpwd->new_pwd + "' where user_id='" + findpwd->user_id + "'";
    bool result_success =  result.exec(insertSql);
    if(!result_success){
        QMessageBox::information(this,"错误","新密码保存失败");
    }
}

//返回登录
void login::back_login()
{
    this->show();
}

//显示记录
void login::show_record(int type, QString friend_id)
{
    QString sql;
    //type为1是查询，为0是清空记录
    if(type == 1) {
        sql = "select * from chat_log where user_id = '" + ui->user->currentText() + "' and user_chat_id = '"+ friend_id
                + "' and create_date>date_format('" + this->mainwindow->record->startDate
                + "','%Y-%m-%d') and create_date<date_format('" + this->mainwindow->record->endDate + "','%Y-%m-%d')";
        result.clear();
        result = db.exec(sql);
        while(result.next()){
            qDebug() << result.value(0).toInt();
            QString user = result.value("user_id").toString();
            QString time = result.value("create_date").toString();
            QString log_text = result.value("log_text").toString();
            QString msg = time + " " + user + " => " + friend_id + ": \n" + log_text + "\n";
            emit show_record_msg(type, msg);
        }
    } else if(type == 0) {
        sql = "delete from chat_log where user_id = '" + ui->user->currentText() + "' and user_chat_id = '"+ friend_id +"'";
        qDebug()<<sql;
        result.clear();
        bool result_success = result.exec(sql);
        if(!result_success){
            QMessageBox::information(this,"错误","删除聊天记录失败");
            return;
        }
    }

}

//判断字符串是否为数字
bool string_is_number(QString input)
{
    QByteArray num;
    const char *s;
    int count;

    //QString 转换为 char*
    num = input.toLatin1();
    s = num.data();

    count = 0;
    while(*s && *s>='0' && *s<='9') {
        s++;
        count++;
    }

    return ((*s || count != 8) ? false : true);
}

//添加好友，校验输入的好友id
bool login::checkFriendId(QString user_id)
{
    QString errmsg, sql;
    bool flag;

    flag = false;
    if(user_id.isEmpty()) {
        errmsg = "ID不允许为空！";
        flag = false;
    } else if (!string_is_number(user_id)) {
        errmsg = "ID不合法，为八位数字！";
        flag = false;
    } else if(user_id.compare(ui->user->currentText()) == 0) {
        errmsg = "不能添加自己为好友！";
        flag = false;
    } else {
        sql = "select count(*) from user_info where user_id = '" + user_id + "'";
        result.clear();
        result = db.exec(sql);
        while(result.next()){
            qDebug() << "CHECK FRIENDLY" << result.value(0).toInt();
            flag = result.value(0).toInt() == 1 ? true : false;
        }
        if(!flag)
        errmsg = "无此用户...";
    }

    if(!flag) {
        QMessageBox::about(NULL, "Infomation!", errmsg);
        return flag;
    }

    return flag;
}

//添加好友
void login::addFriend(QString user_id)
{
    QString sendmsg, sendTime, sta, sql, friend_name;
    bool flag;

    if(!checkFriendId(user_id)) {
        QMessageBox::about(mainwindow, "Infomation!", "添加好友失败，无此用户ID, 请重试...");
        return;
    }

    flag = false;
    sql = "select count(*) from friend_list where user_id = '" + ui->user->currentText() + "' and friendly_id = '"+ user_id +"'";
    qDebug() << "add friend" << user_id << ui->user->currentText() << sql;
    result.clear();
    result = db.exec(sql);
    while(result.next()){
        qDebug() << "是否已添加好友: " << result.value(0).toInt();
        flag = result.value(0).toInt() == 0 ? true : false;
    }

    if(!flag) {
        QMessageBox::about(mainwindow, "Infomation!", "已添加此好友，无需重复添加...");
        return;
    }

    /* 查询好友状态 */
    sql = "select user_state, user_name from user_info where user_id = '" + user_id + "'";
    result.clear();
    result = db.exec(sql);
    while(result.next()){
        sta = result.value("user_state").toString();
        friend_name = result.value("user_name").toString();
        qDebug() << "好友状态: " << sta;
        qDebug() << "好友名字: " << friend_name;
    }

    /* 发送服务器添加好友 */
    sendTime = QDateTime::currentDateTime().toString("yyyy-M-dd hh:mm:ss");
    sendmsg = "friend|"+ ui->user->currentText() + "|" + user_id + "|" + sendTime + "|" + friend_name + "|" + sta;
    qDebug() << "添加好友 sql: " <<sendmsg;
    this->clientsocket->write(sendmsg.toUtf8());

//    /* 更新好友列表 */
//    QStringListModel *userListModel = new QStringListModel(getUserList());
//    QStringList userlist = getPrivateUser();
//    qDebug() << "show friend: " << userlist;
//    emit usedb(userListModel, userlist);

//    QMessageBox::about(mainwindow, "Infomation!", "添加好友，ID: " + user_id + "成功");
}

//获取用户列表
QStringList login::getUserList(){
    QStringList uList;
    QString sql;
    result.clear();
    sql = "select friendly_id, friendly_state from friend_list where user_id = '" + ui->user->currentText() + "'";
    result = db.exec(sql);

    while(result.next()){
        QString sta = (result.value("friendly_state").toString().compare("01") == 0) ? "下线" : "在线";
        QString user = result.value("friendly_id").toString() + " | " + sta;
        qDebug() << "friend_sta: " << sta;
        qDebug() << "friend_id: " << user;
        uList.append(user);
        mainwindow->record->userlist.append(result.value("friendly_id").toString());
    } 
    return uList;
}

//在线用户列表
QStringList login::getPrivateUser(){
    QStringList pList;
    QString sql;

    sql = "select friendly_id from friend_list where friendly_state not in ('01') and user_id = '" + ui->user->currentText() + "'";
    result.clear();
    result = db.exec(sql);
    qDebug() << "select friendly_id from friend_list where friendly_state not in ('01') and user_id = '" + ui->user->currentText() + "'";
    while (result.next()) {
        QString user = result.value("friendly_id").toString();
        qDebug() << "friend_id: " << user;
        pList.append(user);
    }
    return pList;
}

/*
 * 登录下拉框变化（记住密码）
 */
void login::changeUsername()
{
    int index = ui->user->findText(ui->user->currentText());
    QString user = this->remPWD[QString::number(index)];

    if(index != -1 &&  user.compare(ui->user->currentText()) == 0) {
        ui->pwd->setText(this->remPWD[ui->user->currentText()]);
        QMessageBox::about(this, " ", "");
    } else {
        QMessageBox::about(this, " 1", "");
        ui->pwd->clear();
    }
}

/*
判断输入的密码是否一致
*/
bool checkPwd(QString pwdStr, QString pwdCFStr){
    int x = QString::compare(pwdStr,pwdCFStr,Qt::CaseSensitive);//Qt::CaseSensitive表示大小写敏感的判断方式
    if(x==0){
        return true;
    }else{
        return false;
    }
}

/*
 * 读取服务器地址
 */
QString read_server_ip()
{
    QString ip_addr = "";
    QFile aFile(":/media/media/ServerIp.txt");
    if (!aFile.exists()) //文件不存在
        qDebug() << "文件不存在";
    if (!aFile.open(QIODevice::ReadOnly | QIODevice::Text))
        qDebug() << "读取失败";
    //qDebug() <<"ip: "<<aFile.readAll();
    ip_addr = aFile.readAll();
    qDebug() << "ip_addr:" << ip_addr;
    aFile.close();

    return  ip_addr;
}

/*
 * 连接服务器
 */
bool login::connect_server()
{
    QString ip_addr = "";

    if(serverConnect) {
        return true;
    }

    ip_addr = read_server_ip();
    if(ip_addr.isEmpty()) {
        QMessageBox::information(this, "info", "服务器地址出错");
        return false;
    }

    clientsocket->connectToHost(ip_addr,8765);
    //clientsocket->connectToHost("127.0.0.1",8765);
    /* 10s连接，超时则连接失败*/
    serverConnect = clientsocket->waitForConnected(1000) ? true : false;
    if(!serverConnect) {
        QMessageBox::about(NULL, "Infomation!", "连接服务器失败，请重试...");
    } else {
        connect(clientsocket,SIGNAL(readyRead()),this,SLOT(read_msg()));
    }

    return serverConnect;
}

//格式化信息并转发
void login::forwardMsg(QString msg)
{
    QByteArray datagram;

    datagram = msg.toUtf8();
    //clientsocket->write(msg.toLatin1());
    clientsocket->write(msg.toLocal8Bit());
}

/*
 * 读取服务器转发的消息
 */
void login::read_msg()
{
    QTcpSocket *clientsocket;
    QByteArray buff;
    /* 消息格式: type|sendUser|receiveUser|dataTime|msg */
    QString receiveMsg, chat_text, sendmsg, msgbrower, user_id;
    QStringList split_msg;
    bool saveMsgFlag = false;

    //接受信息，并拆分
    clientsocket=(QTcpSocket *)QObject::sender();
    buff=clientsocket->readAll();
//    receiveMsg.prepend(buff);
    receiveMsg = QString::fromLocal8Bit(buff);
    chat_text = receiveMsg;
    split_msg = receiveMsg.split('|');

    if(split_msg[0] == "connect") {
        msgbrower = "用户: " + split_msg[1] +" 加入聊天室.\n";
        emit sendChildmsg(msgbrower, ui->user->currentText());
        //更新ListView的值
        QStringListModel *userListModel = new QStringListModel(getUserList());
        //更新comboBox的值
        QStringList userlist = getPrivateUser();
        emit usedb(userListModel, userlist);
    } else if(split_msg[0] == "exit") {
        msgbrower = "用户: " + split_msg[1] +" 离开聊天室.\n";
        emit sendChildmsg(msgbrower, ui->user->currentText());
    } else if(split_msg[0] == "private" || split_msg[0] == "group") {
        msgbrower = split_msg[4] + " " + split_msg[1] + " => " + split_msg[2] + + ":\n" + split_msg[5] + "\n";
        qDebug() << "聊天记录：" << msgbrower;
        emit sendChildmsg(msgbrower, ui->user->currentText());
        /* 托盘闪烁 */
        this->show_timer->start(300);
        this->timer->start(5000);
        /* 消息提示音 */
        QString file = split_msg[0] == "private" ? ":/media/media/private.mp3" : ":/media/media/group.mp3";
        QSound bell(file);
        bell.play();
    } else if(split_msg[0] == "friend") {
        /* 更新好友列表 */
        QStringListModel *userListModel = new QStringListModel(getUserList());
        QStringList userlist = getPrivateUser();
        qDebug() << "show friend: " << userlist;
        emit usedb(userListModel, userlist);

        QMessageBox::about(mainwindow, "Infomation!", "添加好友，ID: " + user_id + "成功");
    } else {
        //todo
    }
}

//返回
void login::on_regBtn_clicked()
{
    if(!connect_server()) {
        return;
    }

    this->hide();
    regist->show();
}

//更新状态
void login::show_login(QString type)
{
    QString sendTime, sendmsg;
    /* 发送消息更新数据库状态 */
    sendTime = QDateTime::currentDateTime().toString("yyyy-M-dd hh:mm:ss");
    if(type.compare("exit") == 0) {
        sendmsg = "exit|"+ ui->user->currentText() + "|server|" + sendTime + "|01";
    } else if(type.compare("register") == 0)
    sendmsg = "register|"+ this->new_userid + "|server|" + sendTime;
    this->clientsocket->write(sendmsg.toLatin1());
    this->show();
}

/*
 * 判断登录用户名
 */
bool login::checkUser()
{
    QString sql;
    sql = "select count(*) from user_info where user_id = '" + ui->user->currentText() + "' and user_pwd = '" + ui->pwd->text() + "'";
    result.clear();
    result = db.exec(sql);
    while(result.next()){
        qDebug() << result.value(0).toInt();
        return result.value(0).toInt();
    }
    return false;
}

//登录信息
bool login::LoginInMain()
{
    QString errmsg;
    bool flag;

    flag = false;
    if(ui->user->findText(ui->user->currentText()) != -1) {
        errmsg = QString::number(ui->user->currentIndex());
    }
    else if(ui->user->currentText().isEmpty() || ui->pwd->text().isEmpty()) {
        errmsg = "用户名或密码不允许为空！";
        flag = false;
    } else if (!string_is_number(ui->user->currentText())) {
        errmsg = "用户名不合法，为八位数字！";
        flag = false;
    } else if(!serverConnect){
        errmsg = "连接服务器超时，请重试...";
        flag = false;
    } else if(!checkUser()) {
        errmsg = "用户名或密码错误，请重试...";
        flag = false;
    } else {
        errmsg = "登录成功，点击确定跳转至主界面...";
        flag = true;
    }
    QMessageBox::about(NULL, "Infomation!", errmsg);

    return flag;
}

//登录按钮槽函数
void login::on_loginBtn_clicked()
{
    QString sendmsg, msg;
    QString sendTime;

    if(!connect_server()) {
        return;
    }

    if(!LoginInMain()) {
        return;
    }

    //记住密码则更新最外的框
    if(ui->remberpwd->isChecked()) {
        ui->user->addItem(ui->user->currentText());
        this->remPWD.insert(ui->user->currentText(), ui->pwd->text());
    }

    /* 发送消息更新数据库状态 */
    sendTime = QDateTime::currentDateTime().toString("yyyy-M-dd hh:mm:ss");
    sendmsg = "connect|"+ ui->user->currentText() + "|server|" + sendTime + "|00";
//    this->clientsocket->write(sendmsg.toLatin1());
    this->clientsocket->write(sendmsg.toLocal8Bit());

    this->hide();
    mainwindow->show();
}

void login::on_findPwdBtn_clicked()
{
    if(!connect_server()) {
        return;
    }
    this->hide();
    this->findpwd->show();
}

void login::on_exitBtn_clicked()
{
    QMessageBox::about(NULL, "Infomation!", "欢迎下次使用...");
    this->close();
}

//检验用户号码唯一性
bool login::is_user_exist(QString user_code)
{
    result.clear();
    result = db.exec("select user_id from user_info where user_id='" + user_code + "'");
    while(result.next()){
        return false;//有结果集就说明该号码已经存在
    }
    return true;
}

//生成用户号码
QString login::generate_userid()
{
    int flag = 0;
    bool usercode_flag;
    int num;
    QString user_code;

    usercode_flag = false;
    while(flag < 30 && !usercode_flag) {
        user_code.clear();
        //8位随机数字
        for(int i=1; i<9; i++) {
            num = qrand() % 10;
            user_code = user_code + QString::number(num);
        }
        qDebug()<<user_code;
        usercode_flag = is_user_exist(user_code) ? true : false;
        flag++;
    }

    user_code = (usercode_flag) ? user_code : "false";
    return user_code;
}
