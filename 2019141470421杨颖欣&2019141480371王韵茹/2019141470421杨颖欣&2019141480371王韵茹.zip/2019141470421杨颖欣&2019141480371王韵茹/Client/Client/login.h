#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include <QWidget>
#include <QMessageBox>
#include <QTcpSocket>
#include <regist.h>
#include <QDateTime>
#include "mainwindow.h"
#include <QStringListModel>
#include "findpwd.h"
#include <QSound>
#include <QSystemTrayIcon>
#include <QIcon>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui {
class login;
}
QT_END_NAMESPACE

class login : public QWidget
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();
    bool LoginInMain();//登录判断
    bool connect_server();//连接服务器
    bool checkUser();//检查用户id是否合法
    bool checkFriendId(QString user_id);//检测查询好友id是否合法
    QStringList getUserList();//更新listView的好友列表
    QStringList getPrivateUser();//更新comboBox的好友列表
    Ui::login *ui;//界面UI

    QSystemTrayIcon m_icon;//托盘类
    QTimer *show_timer;//计时器，所有计时器都是用于判断托盘闪动时间
    QTimer *hide_timer;//计时器
    QTimer *timer;//计时器
    QString new_userid;//新用户注册ID

signals:
    void sendChildmsg(QString msg, QString user_id);//往子界面发送信息
    void usedb(QStringListModel*, QStringList);//数据库操作
    void show_record_msg(int, QString);//查询记录
    void pass_userid(QString);//登录成功

private slots:
    void getUerid(QString);//获取用户id
    void changeUsername();//修改用户名
    void onTimeout();//计时器
    void onshowTimeout();//计时器
    void onhideTimeout();//计时器
    void show_record(int, QString);//注册，更新数据库
    void on_regBtn_clicked();//注册按钮
    void on_loginBtn_clicked();//登录按钮
    void show_login(QString);//登录，更新数据库
    void on_findPwdBtn_clicked();//找回密码按钮
    void on_exitBtn_clicked();//退出按钮
    void read_msg();//读取信息
    void forwardMsg(QString msg);//转发信息
    void addFriend(QString user_id);//添加好友
    void back_login();//返回登录
    void register_user();//注册
    void findpwd_user();//找回密码

private:
    class mainwindow *mainwindow;//主界面类
    class regist *regist;//注册类
    class findPwd *findpwd;//找回密码类
    class records *records;//记录类
    QSqlDatabase db;//处理数据库连接
    QSqlQuery result;//存放数据库语句执行后的结果集
    QTcpSocket *clientsocket;//客户端socket
    bool serverConnect;//服务器是否连接判断
    QMap<QString, QString> remPWD;//记住账户
    bool is_user_exist(QString user_code);//判断用户id是否存在
    QString generate_userid();//生成用户id
};

//extern class login *global_login;

#endif // LOGIN_H
