#include "login.h"
#include "ui_login.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    login login;
    login.show();//主函数，以login为初始界面
    return a.exec();
}
