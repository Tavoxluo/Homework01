#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include "login.h"
#include <QStringListModel>
#include "records.h"

namespace Ui {
class mainwindow;
}

class mainwindow : public QWidget
{
    Q_OBJECT

public:
    explicit mainwindow(QWidget *parent = nullptr);
    ~mainwindow();
    QString userlist;//用户列表
    QString onlinelist;//用户在线列表
    class records *record;//聊天记录

signals:
    void close_main(QString);
    void sendMsg(QString msg);
    void addFriend(QString user_id);
    void updateRecodelist(QStringList box);

private slots:
    void getUsers(QStringListModel *userListModel, QStringList userlist);//更新列表
    void on_closeBtn_clicked();//关闭
    void acceptParentmsg(QString msg, QString user_id);//获取父界面消息
    void on_group_send_clicked();//群发
    void on_friendBtn_clicked();//添加好友
    void on_recordBtn_clicked();//聊天记录
    void on_pri_send_clicked();//私发信息
    void show_mainwindow();//展示主界面

private:
    QString user_id;
    Ui::mainwindow *ui;
};

#endif // MAINWINDOW_H
