#include "records.h"
#include "ui_records.h"

records::records(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::records)
{
    ui->setupUi(this);
    ui->userBox->clear();
    ui->userBox->addItems(this->userlist);
}

records::~records()
{
    delete ui;
}
void records::updateRecodelist(QStringList list)
{
    ui->userBox->clear();
    ui->userBox->addItems(this->userlist);
}

void records::show_record_msg(int type, QString msg)
{
    /* 查询为1 删除为0 */
    if(type == 1) {
        ui->msgBrowser->insertPlainText(msg);
    } else if(type == 0){
        QMessageBox::about(NULL, "warn", "删除成功...");
    }
}

void records::on_searchBtn_2_clicked()
{
    this->close();
    emit close_record();
}

void records::on_searchBtn_clicked()
{
    if(ui->userBox->currentIndex() == -1) {
        QMessageBox::about(NULL, "warn", "请选择要查询的好友...");
        return;
    }
    this->startDate = ui->startDate->text();
    this->endDate = ui->endDate->text();
    ui->msgBrowser->clear();
    emit show_record(1, ui->userBox->currentText());
}

//清除记录
void records::on_clearBtn_clicked()
{
    if(ui->userBox->currentIndex() == -1) {
        QMessageBox::about(NULL, "warn", "请选择要删除记录的好友...");
        return;
    }
    emit show_record(0, ui->userBox->currentText());
}
