#ifndef RECORDS_H
#define RECORDS_H

#include <QWidget>
#include <QMessageBox>

namespace Ui {
class records;
}

class records : public QWidget
{
    Q_OBJECT

public:
    explicit records(QWidget *parent = nullptr);
    ~records();
    QStringList userlist;//用户列表
    QString startDate;//查询的开始日期
    QString endDate;//结束日期

signals:
    void close_record();//关闭
    void show_record(int, QString);//展示

private slots:
    void show_record_msg(int type, QString msg);//展示记录信息
    void updateRecodelist(QStringList);//更新记录列表
    void on_searchBtn_2_clicked();//查询
    void on_searchBtn_clicked();//查询
    void on_clearBtn_clicked();//清理记录

private:
    Ui::records *ui;
};

#endif // RECORDS_H
