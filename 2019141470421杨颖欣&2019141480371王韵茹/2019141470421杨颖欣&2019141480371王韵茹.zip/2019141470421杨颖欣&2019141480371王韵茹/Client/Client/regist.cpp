#include "regist.h"
#include "ui_regist.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QMessageBox>

regist::regist(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::regist)
{
    ui->setupUi(this);
    ui->queBox->addItems(this->pwdQuestion);
}

regist::~regist()
{
    delete ui;
    db = QSqlDatabase::addDatabase("QODBC");
    db.setHostName("127.0.0.1");
    db.setPort(3306);
    db.setDatabaseName("chatTest");
    db.setUserName("root");
    db.setPassword("admin");
    bool dbok = db.open();
    if(!dbok){
        QMessageBox::critical(this,"错误","数据库未启动");
    }
    result = db.exec("use test");
}

void regist::registInit(){
    result.clear();
    QString queStr = "select dict_describe from dicts where dict_code='MBWT'";
    result.exec(queStr);
    while(result.next()){
        ui->queBox->addItem(result.value("dict_describe").toString());
    }
}

void regist::on_rtnBtn_clicked()
{
    this->close();
    emit back_login();
}

//找回密码
void regist::on_regBtn_clicked()
{
    if(ui->pwdLineE->text().isEmpty() || ui->pwdCFLineE->text().isEmpty()) {
        QMessageBox::critical(this,"warn","请输入密码并确认");
        return;
    } else if(ui->pwdLineE->text().compare(ui->pwdCFLineE->text()) != 0) {
        QMessageBox::critical(this,"warn","两次输入密码不一致");
        return;
    } else if(ui->queBox->currentIndex() == -1 || ui->aswLineE->text().isEmpty()) {
        QMessageBox::critical(this,"warn","请选择密保问题，并输入答案");
        return;
    }
    //获取页面数据
    this->user_name = ui->userName->text();
    this->user_que = ui->queBox->currentText();
    this->user_asw = ui->aswLineE->text();
    this->user_pwd = ui->pwdLineE->text();
    emit register_user();
    QMessageBox::information(this,"info","操作成功，点击确定返回登录界面...");
    this->close();
    emit close_regist("register");
}

