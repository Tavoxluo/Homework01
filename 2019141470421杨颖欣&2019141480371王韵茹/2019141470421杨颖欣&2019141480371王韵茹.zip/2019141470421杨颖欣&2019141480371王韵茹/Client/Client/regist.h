#ifndef REGIST_H
#define REGIST_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>

namespace Ui {
class regist;
}

class regist : public QWidget
{
    Q_OBJECT
signals:
    void close_regist(QString);//注册成功返回登录界面
    void register_user();//注册
    void back_login();//取消注册返回登录界面

public:
    explicit regist(QWidget *parent = nullptr);
    ~regist();
    QString user_name;//用户名
    QString user_que;//密保问题
    QString user_asw;//答案
    QString user_pwd;//密码

private slots:
    void on_rtnBtn_clicked();//返回
    void on_regBtn_clicked();//注册

private:
    QStringList pwdQuestion = {//密保问题列表
        {"您的父亲的名字是？"},
        {"您的母亲的名字是？"},
        {"您的配偶的名字是？"},
        {"您的好朋友的名字是"},
        {"您的老师的名字是？"},
        {"您曾就读的小学的名字是？"},
        {"您曾就读的中学的名字是？"}
    };
    Ui::regist *ui;
    QSqlDatabase db;//数据库连接
    QSqlQuery result;//数据库结果集
    void registInit();//注册页面初始化
};

#endif // REGIST_H
