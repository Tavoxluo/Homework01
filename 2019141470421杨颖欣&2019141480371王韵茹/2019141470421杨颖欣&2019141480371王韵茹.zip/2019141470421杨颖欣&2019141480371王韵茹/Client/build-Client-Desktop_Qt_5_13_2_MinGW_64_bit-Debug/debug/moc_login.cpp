/****************************************************************************
** Meta object code from reading C++ file 'login.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Client/login.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'login.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_login_t {
    QByteArrayData data[26];
    char stringdata0[316];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_login_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_login_t qt_meta_stringdata_login = {
    {
QT_MOC_LITERAL(0, 0, 5), // "login"
QT_MOC_LITERAL(1, 6, 12), // "sendChildmsg"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 3), // "msg"
QT_MOC_LITERAL(4, 24, 7), // "user_id"
QT_MOC_LITERAL(5, 32, 5), // "usedb"
QT_MOC_LITERAL(6, 38, 17), // "QStringListModel*"
QT_MOC_LITERAL(7, 56, 15), // "show_record_msg"
QT_MOC_LITERAL(8, 72, 11), // "pass_userid"
QT_MOC_LITERAL(9, 84, 8), // "getUerid"
QT_MOC_LITERAL(10, 93, 14), // "changeUsername"
QT_MOC_LITERAL(11, 108, 9), // "onTimeout"
QT_MOC_LITERAL(12, 118, 13), // "onshowTimeout"
QT_MOC_LITERAL(13, 132, 13), // "onhideTimeout"
QT_MOC_LITERAL(14, 146, 11), // "show_record"
QT_MOC_LITERAL(15, 158, 17), // "on_regBtn_clicked"
QT_MOC_LITERAL(16, 176, 19), // "on_loginBtn_clicked"
QT_MOC_LITERAL(17, 196, 10), // "show_login"
QT_MOC_LITERAL(18, 207, 21), // "on_findPwdBtn_clicked"
QT_MOC_LITERAL(19, 229, 18), // "on_exitBtn_clicked"
QT_MOC_LITERAL(20, 248, 8), // "read_msg"
QT_MOC_LITERAL(21, 257, 10), // "forwardMsg"
QT_MOC_LITERAL(22, 268, 9), // "addFriend"
QT_MOC_LITERAL(23, 278, 10), // "back_login"
QT_MOC_LITERAL(24, 289, 13), // "register_user"
QT_MOC_LITERAL(25, 303, 12) // "findpwd_user"

    },
    "login\0sendChildmsg\0\0msg\0user_id\0usedb\0"
    "QStringListModel*\0show_record_msg\0"
    "pass_userid\0getUerid\0changeUsername\0"
    "onTimeout\0onshowTimeout\0onhideTimeout\0"
    "show_record\0on_regBtn_clicked\0"
    "on_loginBtn_clicked\0show_login\0"
    "on_findPwdBtn_clicked\0on_exitBtn_clicked\0"
    "read_msg\0forwardMsg\0addFriend\0back_login\0"
    "register_user\0findpwd_user"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_login[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      21,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  119,    2, 0x06 /* Public */,
       5,    2,  124,    2, 0x06 /* Public */,
       7,    2,  129,    2, 0x06 /* Public */,
       8,    1,  134,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    1,  137,    2, 0x08 /* Private */,
      10,    0,  140,    2, 0x08 /* Private */,
      11,    0,  141,    2, 0x08 /* Private */,
      12,    0,  142,    2, 0x08 /* Private */,
      13,    0,  143,    2, 0x08 /* Private */,
      14,    2,  144,    2, 0x08 /* Private */,
      15,    0,  149,    2, 0x08 /* Private */,
      16,    0,  150,    2, 0x08 /* Private */,
      17,    1,  151,    2, 0x08 /* Private */,
      18,    0,  154,    2, 0x08 /* Private */,
      19,    0,  155,    2, 0x08 /* Private */,
      20,    0,  156,    2, 0x08 /* Private */,
      21,    1,  157,    2, 0x08 /* Private */,
      22,    1,  160,    2, 0x08 /* Private */,
      23,    0,  163,    2, 0x08 /* Private */,
      24,    0,  164,    2, 0x08 /* Private */,
      25,    0,  165,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QStringList,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void login::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<login *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sendChildmsg((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: _t->usedb((*reinterpret_cast< QStringListModel*(*)>(_a[1])),(*reinterpret_cast< QStringList(*)>(_a[2]))); break;
        case 2: _t->show_record_msg((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 3: _t->pass_userid((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->getUerid((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->changeUsername(); break;
        case 6: _t->onTimeout(); break;
        case 7: _t->onshowTimeout(); break;
        case 8: _t->onhideTimeout(); break;
        case 9: _t->show_record((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 10: _t->on_regBtn_clicked(); break;
        case 11: _t->on_loginBtn_clicked(); break;
        case 12: _t->show_login((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->on_findPwdBtn_clicked(); break;
        case 14: _t->on_exitBtn_clicked(); break;
        case 15: _t->read_msg(); break;
        case 16: _t->forwardMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->addFriend((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->back_login(); break;
        case 19: _t->register_user(); break;
        case 20: _t->findpwd_user(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QStringListModel* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (login::*)(QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&login::sendChildmsg)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (login::*)(QStringListModel * , QStringList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&login::usedb)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (login::*)(int , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&login::show_record_msg)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (login::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&login::pass_userid)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject login::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_login.data,
    qt_meta_data_login,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *login::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *login::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_login.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int login::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    return _id;
}

// SIGNAL 0
void login::sendChildmsg(QString _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void login::usedb(QStringListModel * _t1, QStringList _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void login::show_record_msg(int _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void login::pass_userid(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
