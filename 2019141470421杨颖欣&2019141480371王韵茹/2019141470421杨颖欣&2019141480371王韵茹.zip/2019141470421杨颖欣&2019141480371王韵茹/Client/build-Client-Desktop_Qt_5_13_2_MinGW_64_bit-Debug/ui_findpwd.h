/********************************************************************************
** Form generated from reading UI file 'findpwd.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINDPWD_H
#define UI_FINDPWD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_findPwd
{
public:
    QLabel *title;
    QLabel *queLabel;
    QLabel *aswLabel;
    QLineEdit *aswLineE;
    QPushButton *searchBtn;
    QPushButton *returnBtn;
    QLabel *queLabel_2;
    QLineEdit *aswLineE_2;
    QLabel *queLabel_3;
    QLineEdit *aswLineE_3;
    QLineEdit *aswLineE_4;
    QLabel *queLabel_4;
    QLineEdit *userName;
    QPushButton *userBtn;

    void setupUi(QWidget *findPwd)
    {
        if (findPwd->objectName().isEmpty())
            findPwd->setObjectName(QString::fromUtf8("findPwd"));
        findPwd->resize(558, 422);
        title = new QLabel(findPwd);
        title->setObjectName(QString::fromUtf8("title"));
        title->setGeometry(QRect(230, 40, 130, 30));
        QFont font;
        font.setPointSize(20);
        title->setFont(font);
        queLabel = new QLabel(findPwd);
        queLabel->setObjectName(QString::fromUtf8("queLabel"));
        queLabel->setGeometry(QRect(100, 240, 100, 30));
        QFont font1;
        font1.setPointSize(10);
        queLabel->setFont(font1);
        aswLabel = new QLabel(findPwd);
        aswLabel->setObjectName(QString::fromUtf8("aswLabel"));
        aswLabel->setGeometry(QRect(100, 290, 100, 30));
        aswLabel->setFont(font1);
        aswLineE = new QLineEdit(findPwd);
        aswLineE->setObjectName(QString::fromUtf8("aswLineE"));
        aswLineE->setGeometry(QRect(190, 290, 240, 30));
        aswLineE->setFont(font1);
        searchBtn = new QPushButton(findPwd);
        searchBtn->setObjectName(QString::fromUtf8("searchBtn"));
        searchBtn->setGeometry(QRect(120, 370, 100, 30));
        searchBtn->setFont(font1);
        returnBtn = new QPushButton(findPwd);
        returnBtn->setObjectName(QString::fromUtf8("returnBtn"));
        returnBtn->setGeometry(QRect(310, 370, 100, 30));
        returnBtn->setFont(font1);
        queLabel_2 = new QLabel(findPwd);
        queLabel_2->setObjectName(QString::fromUtf8("queLabel_2"));
        queLabel_2->setGeometry(QRect(100, 190, 100, 30));
        queLabel_2->setFont(font1);
        aswLineE_2 = new QLineEdit(findPwd);
        aswLineE_2->setObjectName(QString::fromUtf8("aswLineE_2"));
        aswLineE_2->setGeometry(QRect(190, 190, 240, 30));
        aswLineE_2->setFont(font1);
        queLabel_3 = new QLabel(findPwd);
        queLabel_3->setObjectName(QString::fromUtf8("queLabel_3"));
        queLabel_3->setGeometry(QRect(100, 140, 100, 30));
        queLabel_3->setFont(font1);
        aswLineE_3 = new QLineEdit(findPwd);
        aswLineE_3->setObjectName(QString::fromUtf8("aswLineE_3"));
        aswLineE_3->setGeometry(QRect(190, 140, 240, 30));
        aswLineE_3->setFont(font1);
        aswLineE_4 = new QLineEdit(findPwd);
        aswLineE_4->setObjectName(QString::fromUtf8("aswLineE_4"));
        aswLineE_4->setEnabled(false);
        aswLineE_4->setGeometry(QRect(190, 240, 240, 30));
        aswLineE_4->setFont(font1);
        queLabel_4 = new QLabel(findPwd);
        queLabel_4->setObjectName(QString::fromUtf8("queLabel_4"));
        queLabel_4->setGeometry(QRect(100, 90, 100, 30));
        queLabel_4->setFont(font1);
        userName = new QLineEdit(findPwd);
        userName->setObjectName(QString::fromUtf8("userName"));
        userName->setGeometry(QRect(190, 90, 240, 30));
        userName->setFont(font1);
        userBtn = new QPushButton(findPwd);
        userBtn->setObjectName(QString::fromUtf8("userBtn"));
        userBtn->setGeometry(QRect(450, 90, 93, 28));

        retranslateUi(findPwd);

        QMetaObject::connectSlotsByName(findPwd);
    } // setupUi

    void retranslateUi(QWidget *findPwd)
    {
        findPwd->setWindowTitle(QCoreApplication::translate("findPwd", "\346\211\276\345\233\236\345\257\206\347\240\201", nullptr));
        title->setText(QCoreApplication::translate("findPwd", "\344\277\256\346\224\271\345\257\206\347\240\201", nullptr));
        queLabel->setText(QCoreApplication::translate("findPwd", "\345\257\206\344\277\235\351\227\256\351\242\230\357\274\232", nullptr));
        aswLabel->setText(QCoreApplication::translate("findPwd", "\345\257\206\344\277\235\347\255\224\346\241\210\357\274\232", nullptr));
        aswLineE->setInputMask(QString());
        aswLineE->setPlaceholderText(QCoreApplication::translate("findPwd", "\350\257\267\350\276\223\345\205\245\351\227\256\351\242\230\347\255\224\346\241\210", nullptr));
        searchBtn->setText(QCoreApplication::translate("findPwd", "\347\241\256  \350\256\244", nullptr));
        returnBtn->setText(QCoreApplication::translate("findPwd", "\350\277\224  \345\233\236", nullptr));
        queLabel_2->setText(QCoreApplication::translate("findPwd", "\347\241\256\350\256\244\345\257\206\347\240\201", nullptr));
        aswLineE_2->setInputMask(QString());
        aswLineE_2->setPlaceholderText(QCoreApplication::translate("findPwd", "\351\207\215\345\244\215\346\226\260\345\257\206\347\240\201", nullptr));
        queLabel_3->setText(QCoreApplication::translate("findPwd", "\346\226\260\345\257\206\347\240\201", nullptr));
        aswLineE_3->setInputMask(QString());
        aswLineE_3->setPlaceholderText(QCoreApplication::translate("findPwd", "\350\276\223\345\205\245\346\226\260\345\257\206\347\240\201", nullptr));
        aswLineE_4->setInputMask(QString());
        aswLineE_4->setPlaceholderText(QString());
        queLabel_4->setText(QCoreApplication::translate("findPwd", "\347\224\250\346\210\267\345\220\215", nullptr));
        userName->setInputMask(QString());
        userName->setPlaceholderText(QString());
        userBtn->setText(QCoreApplication::translate("findPwd", "\346\237\245\346\211\276", nullptr));
    } // retranslateUi

};

namespace Ui {
    class findPwd: public Ui_findPwd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINDPWD_H
