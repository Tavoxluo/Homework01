/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_login
{
public:
    QLabel *loginTitle;
    QLabel *userLabel;
    QLabel *pwdLabel;
    QLineEdit *pwd;
    QPushButton *loginBtn;
    QPushButton *findPwdBtn;
    QPushButton *regBtn;
    QComboBox *user;
    QPushButton *exitBtn;
    QCheckBox *remberpwd;

    void setupUi(QWidget *login)
    {
        if (login->objectName().isEmpty())
            login->setObjectName(QString::fromUtf8("login"));
        login->resize(496, 253);
        QFont font;
        font.setPointSize(7);
        login->setFont(font);
        loginTitle = new QLabel(login);
        loginTitle->setObjectName(QString::fromUtf8("loginTitle"));
        loginTitle->setGeometry(QRect(160, 30, 251, 41));
        QFont font1;
        font1.setPointSize(20);
        loginTitle->setFont(font1);
        loginTitle->setTextFormat(Qt::AutoText);
        loginTitle->setAlignment(Qt::AlignCenter);
        loginTitle->setIndent(-1);
        userLabel = new QLabel(login);
        userLabel->setObjectName(QString::fromUtf8("userLabel"));
        userLabel->setGeometry(QRect(30, 80, 100, 30));
        QFont font2;
        font2.setPointSize(10);
        userLabel->setFont(font2);
        userLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        pwdLabel = new QLabel(login);
        pwdLabel->setObjectName(QString::fromUtf8("pwdLabel"));
        pwdLabel->setGeometry(QRect(30, 140, 100, 30));
        pwdLabel->setFont(font2);
        pwdLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        pwd = new QLineEdit(login);
        pwd->setObjectName(QString::fromUtf8("pwd"));
        pwd->setGeometry(QRect(150, 140, 300, 30));
        pwd->setFont(font2);
        loginBtn = new QPushButton(login);
        loginBtn->setObjectName(QString::fromUtf8("loginBtn"));
        loginBtn->setGeometry(QRect(130, 210, 100, 30));
        QFont font3;
        font3.setPointSize(12);
        loginBtn->setFont(font3);
        findPwdBtn = new QPushButton(login);
        findPwdBtn->setObjectName(QString::fromUtf8("findPwdBtn"));
        findPwdBtn->setGeometry(QRect(250, 210, 100, 30));
        findPwdBtn->setFont(font3);
        regBtn = new QPushButton(login);
        regBtn->setObjectName(QString::fromUtf8("regBtn"));
        regBtn->setGeometry(QRect(20, 210, 100, 30));
        regBtn->setFont(font3);
        user = new QComboBox(login);
        user->setObjectName(QString::fromUtf8("user"));
        user->setGeometry(QRect(150, 80, 301, 30));
        user->setFont(font2);
        user->setEditable(true);
        exitBtn = new QPushButton(login);
        exitBtn->setObjectName(QString::fromUtf8("exitBtn"));
        exitBtn->setGeometry(QRect(370, 210, 100, 30));
        exitBtn->setFont(font3);
        remberpwd = new QCheckBox(login);
        remberpwd->setObjectName(QString::fromUtf8("remberpwd"));
        remberpwd->setGeometry(QRect(80, 180, 91, 19));

        retranslateUi(login);

        QMetaObject::connectSlotsByName(login);
    } // setupUi

    void retranslateUi(QWidget *login)
    {
        login->setWindowTitle(QCoreApplication::translate("login", "\347\231\273\345\275\225\347\225\214\351\235\242", nullptr));
        loginTitle->setText(QCoreApplication::translate("login", "\347\224\250\346\210\267\347\231\273\345\275\225", nullptr));
        userLabel->setText(QCoreApplication::translate("login", "\347\224\250\346\210\267\345\220\215", nullptr));
        pwdLabel->setText(QCoreApplication::translate("login", "\345\257\206  \347\240\201", nullptr));
        pwd->setInputMask(QString());
        pwd->setText(QString());
        pwd->setPlaceholderText(QCoreApplication::translate("login", "\350\257\267\350\276\223\345\205\245\346\202\250\347\232\204\345\257\206\347\240\201", nullptr));
        loginBtn->setText(QCoreApplication::translate("login", "\347\231\273  \345\275\225", nullptr));
        findPwdBtn->setText(QCoreApplication::translate("login", "\346\211\276\345\233\236\345\257\206\347\240\201", nullptr));
        regBtn->setText(QCoreApplication::translate("login", "\346\263\250  \345\206\214", nullptr));
        exitBtn->setText(QCoreApplication::translate("login", "\351\200\200  \345\207\272", nullptr));
        remberpwd->setText(QCoreApplication::translate("login", "\350\256\260\344\275\217\345\257\206\347\240\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class login: public Ui_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
