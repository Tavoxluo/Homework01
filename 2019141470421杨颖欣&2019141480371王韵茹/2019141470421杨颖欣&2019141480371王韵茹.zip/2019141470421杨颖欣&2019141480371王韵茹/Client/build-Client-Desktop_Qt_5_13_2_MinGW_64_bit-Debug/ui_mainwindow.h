/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mainwindow
{
public:
    QTextBrowser *msgBro;
    QLineEdit *msgLineE;
    QListView *userList;
    QPushButton *closeBtn;
    QPushButton *group_send;
    QPushButton *recordBtn;
    QComboBox *userBox;
    QDateEdit *dateEdit;
    QDateEdit *dateEdit_2;
    QLabel *label;
    QLineEdit *friendLineE;
    QPushButton *friendBtn;
    QPushButton *pri_send;

    void setupUi(QWidget *mainwindow)
    {
        if (mainwindow->objectName().isEmpty())
            mainwindow->setObjectName(QString::fromUtf8("mainwindow"));
        mainwindow->resize(760, 520);
        msgBro = new QTextBrowser(mainwindow);
        msgBro->setObjectName(QString::fromUtf8("msgBro"));
        msgBro->setGeometry(QRect(20, 20, 450, 300));
        QFont font;
        font.setPointSize(10);
        msgBro->setFont(font);
        msgLineE = new QLineEdit(mainwindow);
        msgLineE->setObjectName(QString::fromUtf8("msgLineE"));
        msgLineE->setGeometry(QRect(20, 330, 450, 100));
        msgLineE->setFont(font);
        msgLineE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        userList = new QListView(mainwindow);
        userList->setObjectName(QString::fromUtf8("userList"));
        userList->setGeometry(QRect(490, 20, 250, 300));
        userList->setFont(font);
        closeBtn = new QPushButton(mainwindow);
        closeBtn->setObjectName(QString::fromUtf8("closeBtn"));
        closeBtn->setGeometry(QRect(640, 400, 100, 30));
        group_send = new QPushButton(mainwindow);
        group_send->setObjectName(QString::fromUtf8("group_send"));
        group_send->setGeometry(QRect(370, 450, 100, 30));
        group_send->setFont(font);
        recordBtn = new QPushButton(mainwindow);
        recordBtn->setObjectName(QString::fromUtf8("recordBtn"));
        recordBtn->setGeometry(QRect(480, 400, 100, 30));
        recordBtn->setFont(font);
        userBox = new QComboBox(mainwindow);
        userBox->setObjectName(QString::fromUtf8("userBox"));
        userBox->setGeometry(QRect(20, 450, 200, 30));
        userBox->setFont(font);
        dateEdit = new QDateEdit(mainwindow);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setGeometry(QRect(630, 450, 120, 30));
        dateEdit->setFont(font);
        dateEdit->setDateTime(QDateTime(QDate(2021, 6, 1), QTime(0, 0, 0)));
        dateEdit_2 = new QDateEdit(mainwindow);
        dateEdit_2->setObjectName(QString::fromUtf8("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(480, 450, 120, 30));
        dateEdit_2->setFont(font);
        dateEdit_2->setDateTime(QDateTime(QDate(2021, 6, 2), QTime(0, 0, 0)));
        label = new QLabel(mainwindow);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(590, 450, 50, 30));
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);
        friendLineE = new QLineEdit(mainwindow);
        friendLineE->setObjectName(QString::fromUtf8("friendLineE"));
        friendLineE->setGeometry(QRect(480, 350, 171, 30));
        friendLineE->setFont(font);
        friendBtn = new QPushButton(mainwindow);
        friendBtn->setObjectName(QString::fromUtf8("friendBtn"));
        friendBtn->setGeometry(QRect(650, 350, 91, 31));
        friendBtn->setFont(font);
        pri_send = new QPushButton(mainwindow);
        pri_send->setObjectName(QString::fromUtf8("pri_send"));
        pri_send->setGeometry(QRect(260, 450, 100, 30));
        pri_send->setFont(font);

        retranslateUi(mainwindow);

        QMetaObject::connectSlotsByName(mainwindow);
    } // setupUi

    void retranslateUi(QWidget *mainwindow)
    {
        mainwindow->setWindowTitle(QCoreApplication::translate("mainwindow", "\350\201\212\345\244\251\347\225\214\351\235\242", nullptr));
        closeBtn->setText(QCoreApplication::translate("mainwindow", "\351\200\200\345\207\272\347\231\273\345\275\225", nullptr));
        group_send->setText(QCoreApplication::translate("mainwindow", "\347\276\244  \350\201\212", nullptr));
        recordBtn->setText(QCoreApplication::translate("mainwindow", "\346\237\245\350\257\242\350\256\260\345\275\225", nullptr));
        label->setText(QCoreApplication::translate("mainwindow", "\350\207\263", nullptr));
        friendLineE->setInputMask(QString());
        friendLineE->setPlaceholderText(QCoreApplication::translate("mainwindow", "\350\276\223\345\205\245\347\224\250\346\210\267\345\217\267\346\267\273\345\212\240\345\245\275\345\217\213", nullptr));
        friendBtn->setText(QCoreApplication::translate("mainwindow", "\346\267\273\345\212\240\345\245\275\345\217\213", nullptr));
        pri_send->setText(QCoreApplication::translate("mainwindow", "\347\247\201  \350\201\212", nullptr));
    } // retranslateUi

};

namespace Ui {
    class mainwindow: public Ui_mainwindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
