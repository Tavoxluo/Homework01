/********************************************************************************
** Form generated from reading UI file 'records.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECORDS_H
#define UI_RECORDS_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_records
{
public:
    QTextBrowser *msgBrowser;
    QLabel *userTitle;
    QComboBox *userBox;
    QPushButton *searchBtn;
    QPushButton *clearBtn;
    QDateEdit *startDate;
    QLabel *startLabel;
    QLabel *endLabel;
    QDateEdit *endDate;
    QPushButton *searchBtn_2;

    void setupUi(QWidget *records)
    {
        if (records->objectName().isEmpty())
            records->setObjectName(QString::fromUtf8("records"));
        records->resize(693, 486);
        msgBrowser = new QTextBrowser(records);
        msgBrowser->setObjectName(QString::fromUtf8("msgBrowser"));
        msgBrowser->setGeometry(QRect(20, 20, 421, 431));
        msgBrowser->setReadOnly(true);
        userTitle = new QLabel(records);
        userTitle->setObjectName(QString::fromUtf8("userTitle"));
        userTitle->setGeometry(QRect(460, 30, 120, 30));
        QFont font;
        font.setPointSize(10);
        userTitle->setFont(font);
        userBox = new QComboBox(records);
        userBox->setObjectName(QString::fromUtf8("userBox"));
        userBox->setEnabled(true);
        userBox->setGeometry(QRect(460, 70, 210, 30));
        userBox->setFont(font);
        searchBtn = new QPushButton(records);
        searchBtn->setObjectName(QString::fromUtf8("searchBtn"));
        searchBtn->setGeometry(QRect(460, 210, 80, 30));
        searchBtn->setFont(font);
        clearBtn = new QPushButton(records);
        clearBtn->setObjectName(QString::fromUtf8("clearBtn"));
        clearBtn->setGeometry(QRect(590, 210, 80, 30));
        clearBtn->setFont(font);
        startDate = new QDateEdit(records);
        startDate->setObjectName(QString::fromUtf8("startDate"));
        startDate->setGeometry(QRect(550, 120, 120, 30));
        startDate->setFont(font);
        startDate->setDateTime(QDateTime(QDate(2021, 6, 1), QTime(0, 0, 0)));
        startLabel = new QLabel(records);
        startLabel->setObjectName(QString::fromUtf8("startLabel"));
        startLabel->setGeometry(QRect(460, 120, 100, 30));
        startLabel->setFont(font);
        endLabel = new QLabel(records);
        endLabel->setObjectName(QString::fromUtf8("endLabel"));
        endLabel->setGeometry(QRect(460, 170, 100, 30));
        endLabel->setFont(font);
        endDate = new QDateEdit(records);
        endDate->setObjectName(QString::fromUtf8("endDate"));
        endDate->setGeometry(QRect(550, 170, 120, 30));
        endDate->setFont(font);
        endDate->setDateTime(QDateTime(QDate(2021, 6, 2), QTime(0, 0, 0)));
        searchBtn_2 = new QPushButton(records);
        searchBtn_2->setObjectName(QString::fromUtf8("searchBtn_2"));
        searchBtn_2->setGeometry(QRect(460, 280, 80, 30));
        searchBtn_2->setFont(font);

        retranslateUi(records);

        QMetaObject::connectSlotsByName(records);
    } // setupUi

    void retranslateUi(QWidget *records)
    {
        records->setWindowTitle(QCoreApplication::translate("records", "\350\201\212\345\244\251\350\256\260\345\275\225", nullptr));
        userTitle->setText(QCoreApplication::translate("records", "\346\237\245\350\257\242\347\232\204\347\224\250\346\210\267\357\274\232", nullptr));
        searchBtn->setText(QCoreApplication::translate("records", "\346\237\245  \350\257\242", nullptr));
        clearBtn->setText(QCoreApplication::translate("records", "\346\270\205\351\231\244\350\256\260\345\275\225", nullptr));
        startLabel->setText(QCoreApplication::translate("records", "\350\265\267\345\247\213\346\227\266\351\227\264\357\274\232", nullptr));
        endLabel->setText(QCoreApplication::translate("records", "\347\273\223\346\235\237\346\227\266\351\227\264\357\274\232", nullptr));
        searchBtn_2->setText(QCoreApplication::translate("records", "\350\277\224  \345\233\236", nullptr));
    } // retranslateUi

};

namespace Ui {
    class records: public Ui_records {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECORDS_H
