#include <QApplication>
#include "server.h"
#include "ui_server.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    server server;
    server.show();
    return a.exec();
}
