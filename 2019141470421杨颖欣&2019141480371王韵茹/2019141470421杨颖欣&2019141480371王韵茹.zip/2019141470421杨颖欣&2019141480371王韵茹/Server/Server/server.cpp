#include "server.h"
#include "ui_server.h"

#include <QMessageBox>
#include <QDateTime>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <QStringListModel>

server::server(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::server)
{
    ui->setupUi(this);

    serverEnable = false;
    tcpServer = new QTcpServer();

    db = QSqlDatabase::addDatabase("QODBC");
    db.setHostName("127.0.0.1");
    db.setPort(3306);
    db.setDatabaseName("chatTest");
    db.setUserName("root");
    db.setPassword("1233211234567");
    bool dbok = db.open();
    if(!dbok){
        QMessageBox::critical(this,"错误","数据库未启动");
    }
    //连接test数据库
    result = db.exec("use test");
    sender = new QUdpSocket(this);//初始化socket
}

server::~server()
{
    delete ui;
}

/*
 * 服务端转发消息
 */
void server::forwardMsg(QString type, QString reve_user, QString msg)
{
    QByteArray datagram;
    int i;
    //data转uft8的byte
    datagram = msg.toUtf8();

    if(type.compare("private") == 0 || type.compare("error") == 0) {
        clients[reve_user]->write(msg.toLocal8Bit());
    } else if(type.compare("friend") == 0) {
        clients[reve_user]->write(msg.toLocal8Bit());
    } else {
        for(i=0; i<cli_sockets.count(); i++) {
            //cli_sockets[i]->write(msg.toLatin1());
            cli_sockets[i]->write(msg.toLocal8Bit());
        }
    }
}

/*
 * 发送信息保存数据库
 */
bool server::saveMessage(QString msg)
{
    QString sqlquery;
    bool result_successed;
    QStringList listmsg;

    //拆分消息
    listmsg = msg.split('|');

    //根据消息类型来执行数据操作
    if(listmsg[0].compare("connect") == 0 || listmsg[0].compare("exit") == 0) {
        //connect表示用户连接，更新用户状态
        sqlquery = "UPDATE users_detail set user_state = '"+listmsg[4]+"' where user_id = '"+listmsg[1]+"'";
    } else if(listmsg[0].compare("private") == 0 || listmsg[0].compare("group") == 0){
        //private表示私发信息，存入记录表
        sqlquery = "INSERT INTO chat_log (log_id, user_id, user_chat_id, user_chat_state, create_date, log_text) "
                   "values(uuid(),'"+listmsg[1]+"', '"+listmsg[2]+"', '"+listmsg[3]+"', '"+listmsg[4]+"', '"+listmsg[5]+"')";
    } else if(listmsg[0].compare("friend") == 0) {
        //friend表示添加好友，插入好友关系表
        sqlquery = "INSERT INTO friendly (user_id, friendly_id, friendly_name, friendly_special_icon, friendly_state) "
                   "values('"+listmsg[1]+"', '"+listmsg[2]+"', '"+listmsg[3]+"', '00', '"+listmsg[4]+"')";
    } else {
        return true;
    }

    //使用result查询数据之前要clear一下,清除之前查询的结果集
    result.clear();
    result_successed = result.exec(sqlquery);
    return result_successed;
}

/*
 * 读取客户端信息
 * connect: 客户端连接
 * exit: 客户端退出
 * pri: 私聊
 * group: 群聊
 * register: 注册
 */
void server::readMsg()
{
    QTcpSocket *clientsocket;
    QByteArray buff;
    /* 消息格式: type|sendUser|receiveUser|dataTime|msg */
    QString receiveMsg, chat_text, sendmsg, msgbrower, user_id;
    QStringList split_msg;
    bool saveMsgFlag = false;

    clientsocket=(QTcpSocket *)QObject::sender();
    buff=clientsocket->readAll();
    //receiveMsg.prepend(buff);
    receiveMsg = QString::fromLocal8Bit(buff);
    chat_text = receiveMsg;
    split_msg = receiveMsg.split('|');

    qDebug() << "server receive msg: " << receiveMsg;

    /* 操作数据库 */
    saveMsgFlag = saveMessage(chat_text);
    if(!saveMsgFlag) {
        sendmsg = "error|server|" + split_msg[1]+split_msg[0];
        forwardMsg("error", split_msg[1], sendmsg);
        return;
    }

    if(split_msg[0] == "register") {
        //数据库添加用户 新用户注册
        msgbrower = "新用户注册，用户ID: " + split_msg[1] +"\n";
        ui->msgBrowser->insertPlainText(msgbrower);
        return;
    }

    if(split_msg[0] == "connect") {
        clients.insert(split_msg[1], clientsocket);
        sendmsg = "connect|" + split_msg[1] + "|group";
        msgbrower = "用户: " + split_msg[1] +"加入聊天室.\n";
        ui->msgBrowser->insertPlainText(msgbrower);
        /* 获取用户列表 */
        getUsers();
    } else if(split_msg[0] == "exit") {
        for(QVector<QTcpSocket *>::iterator it = cli_sockets.begin(); it != cli_sockets.end(); it++) {
            if(*it == clientsocket) {
                cli_sockets.erase(it);
                break;
            }
        }
        clients.remove(split_msg[1]);
        sendmsg = "exit|" + split_msg[1] + "|group";
        msgbrower = "用户: " + split_msg[1] +"离开聊天室.\n";
        ui->msgBrowser->insertPlainText(msgbrower);
        /* 获取用户列表 */
        getUsers();
    } else if(split_msg[0] == "private" || split_msg[0] == "group") {
        sendmsg = chat_text;
        msgbrower = split_msg[4] + " " + split_msg[1] + " => " + split_msg[2] + ": \n" + split_msg[5] + "\n";
        ui->msgBrowser->insertPlainText(msgbrower);
    } else if(split_msg[0] == "friend"){
        sendmsg = "friend|server|" + split_msg[2];
        //todo
    }

    /* 转发消息 */
    if(split_msg[0] == "private") {
        forwardMsg(split_msg[0], split_msg[2], sendmsg);
    }
    forwardMsg(split_msg[0], split_msg[1], sendmsg);

}

/*
 * 建立客户端的连接
 * 监听客户端发送的消息，通过readMsg函数处理
 */
void server::new_connection()
{
    QTcpSocket *clientsocket;
    QString user_code;

    clientsocket = tcpServer->nextPendingConnection();
    cli_sockets.push_back(clientsocket);
    /* 监听客户端信息 */
    connect(clientsocket,SIGNAL(readyRead()),this,SLOT(readMsg()));

}

/*
 * 读取服务器地址
 */
QString read_server_ip()
{
    QString ip_addr = "";
    QFile aFile(":/media/media/ServerIp.txt");
    if (!aFile.exists()) //文件不存在
        qDebug() << "文件不存在";
    if (!aFile.open(QIODevice::ReadOnly | QIODevice::Text))
        qDebug() << "读取失败";
    //qDebug() <<"ip: "<<aFile.readAll();
    ip_addr = aFile.readAll();
    qDebug() << "ip_addr:" << ip_addr;
    aFile.close();

    return  ip_addr;
}

//打开服务器
void server::on_startBtn_clicked()
{
    QString ip_addr = "";
    QHostAddress ip;

    ip_addr = read_server_ip();
    if(ip_addr.isEmpty()) {
        QMessageBox::information(this, "info", "服务器地址出错");
        return;
    }

    ip.setAddress(ip_addr);
    //tcpServer->listen(QHostAddress::Any,8765)
    if(!tcpServer->listen(ip,8765)) {
        QMessageBox::critical(this,"Server_info","服务器开启失败，请重试...");
        return;
    }
    ui->linkLineEdit->setText(ip_addr);

    QMessageBox::information(this,"Server_info","服务器启动成功! 监听中...");
    this->serverEnable = true;
    /* 开启关闭按钮和发送信息按钮 */
    ui->sendBtn->setEnabled(true);
    ui->endBtn->setEnabled(true);
    ui->label->setText("服务器已开启，监听中...");
    ui->startBtn->setEnabled(false);

    /* 监听连接 */
    connect(tcpServer,SIGNAL(newConnection()),this,SLOT(new_connection()));

    /* 获取用户列表 */
    getUsers();

}

//发送至客户端
//msg是已经组好的可以直接显示的信息，type是显示的类型private 和 public
bool server::sendToClient(QString msg, QString type){
    //QString转QByteArray
    QByteArray datagram = msg.toUtf8();
    if(type=="public"){
        //向所有用户发送
        //writeDatagram函数原型，发送成功返回字节数，否则-1
        if(sender->writeDatagram(datagram.data(),datagram.size(),QHostAddress::Broadcast,8765)==-1)
            return false;
        else
            return true;
    }else{
        //向特定用户IP发送
        QHostAddress serverAddress = QHostAddress("127.0.0.1");
        if(sender->writeDatagram(datagram.data(), datagram.size(),serverAddress, 8765)==-1)
            return false;
        else
            return true;
    }
}

/*
 * 发送聊天消息
 */
void server::on_sendBtn_clicked()
{
    QString sendmsg, sendTime;
    //格式化时间
    sendTime = QDateTime::currentDateTime().toString("yyyy-M-dd hh:mm:ss");
    if(ui->sendLineEdit->text().isEmpty()) {
        QMessageBox::about(NULL, "Infomation!", "发送信息不能为空...");
        return;
    }
    //发送的消息的格式，用|来间隔
    //"group|" + this->user_id +"|group|" + "01|" + sendTime + "|" + ui->msgLineE->text();
    //根据勾选框来判断是否私发用户
    if(ui->privateCheck->checkState() == Qt::Checked) {
        QString user = ui->userBox->currentText();
        qDebug()<<user;
        if(user.isEmpty()) {
            QMessageBox::critical(this,"error","请选择要私发的用户");
            return;
        }
        sendmsg = "private|server|" + user +"|01|" + sendTime + "|" + ui->sendLineEdit->text();
        saveMessage(sendmsg);
        forwardMsg("private", user, sendmsg);
    } else {
        sendmsg = "group|server|group|01|" + sendTime + "|" + ui->sendLineEdit->text();
        saveMessage(sendmsg);
        forwardMsg("group", "group", sendmsg);
    }
    //将发送的消息显示在页面上
    QStringList split_msg = sendmsg.split('|');
    QString msgbrower = split_msg[4] + " " + split_msg[1] + " => " + split_msg[2] + ": \n" + split_msg[5] + "\n";
    ui->msgBrowser->insertPlainText(msgbrower);
    ui->sendLineEdit->clear();
}

//获取在线用户，更新到listView中
QStringList server::getUserList(){
    QStringList uList;
    result.clear();
    //result = db.exec("select user_name from user_info where user_state not in ('01')");
    result = db.exec("select user_id, user_state from user_info where user_state not in ('01')");
    uList.append("用户：");
    while(result.next()){
        QString sta = (result.value("user_state").toString().compare("01") == 0) ? "下线" : "在线";
        QString user = result.value("user_id").toString() + " | " + sta;
        uList.append(user);
    }
    return uList;
}

//获取在线用户，更新到comboBox中
QStringList server::getPrivateUser(){
    QStringList pList;
    result.clear();
    result = db.exec("select user_id from user_info where user_state not in ('01')");
    while (result.next()) {
        QString user = result.value("user_id").toString();
        pList.append(user);
    }
    return pList;
}

//获取用户列表
void server::getUsers(){
    //更新ListView的值
    userListModel = new QStringListModel(getUserList());
    ui->listView->setModel(userListModel);

    //更新comboBox的值
    ui->userBox->clear();
    ui->userBox->addItems(getPrivateUser());
}

//关闭按钮
void server::on_endBtn_clicked()
{
    //设置按钮的可用性
    ui->sendBtn->setEnabled(false);
    ui->endBtn->setEnabled(false);
    ui->label->setText("服务器已关闭");
    ui->startBtn->setEnabled(true);

    /* 清空信息 */
    ui->msgBrowser->clear();
}
