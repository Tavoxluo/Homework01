#ifndef SERVER_H
#define SERVER_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QStringListModel>
#include <QList>
#include <math.h>
#include <QMap>
#include <QtNetwork>
#include <QUdpSocket>
#include <QMessageBox>

namespace Ui {
class server;
}

class server : public QWidget
{
    Q_OBJECT

public:
    explicit server(QWidget *parent = nullptr);
    ~server();
    bool saveMessage(QString msg);//将发送的信息保存至数据库
    void getUsers();//获取用户列表，用于更新listview和combobox
    QStringList getUserList();//在线用户列表--listView
    QStringList getPrivateUser();//在线用户列表--comboBox
    bool sendToClient(QString msg,QString type);//向客户端发送数据
    //QString forwardMsg(QString clientId,QString msg,QString time,QString goalId,QString type);//服务器转发数据
    void forwardMsg(QString type, QString rece_user, QString msg);

private slots:
    void new_connection();//新用户连接
    void readMsg();//读取数据
    void on_startBtn_clicked();//开启服务器
    void on_sendBtn_clicked();//服务器发送数据
    void on_endBtn_clicked();//关闭服务器

private:
    Ui::server *ui;//当前界面ui
    QTcpServer *tcpServer;//tcp服务器
    QTcpSocket *TCP_connectSocket;//socket
    QVector<QTcpSocket *> cli_sockets;//socket
    QMap<QString, QTcpSocket *> clients;//客户端对象
    QUdpSocket *sender;//通信
    QSqlDatabase db;//处理数据库连接
    QSqlQuery result;//存放数据库语句执行后的结果集
    QStringListModel *userListModel;//更新ListView需要这个
    bool serverEnable;  //服务器开启标志
};

#endif // SERVER_H
