/********************************************************************************
** Form generated from reading UI file 'server.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVER_H
#define UI_SERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_server
{
public:
    QTextBrowser *msgBrowser;
    QLineEdit *sendLineEdit;
    QListView *listView;
    QPushButton *startBtn;
    QPushButton *endBtn;
    QLineEdit *linkLineEdit;
    QLabel *label;
    QCheckBox *privateCheck;
    QComboBox *userBox;
    QPushButton *sendBtn;

    void setupUi(QWidget *server)
    {
        if (server->objectName().isEmpty())
            server->setObjectName(QString::fromUtf8("server"));
        server->resize(720, 438);
        msgBrowser = new QTextBrowser(server);
        msgBrowser->setObjectName(QString::fromUtf8("msgBrowser"));
        msgBrowser->setGeometry(QRect(20, 20, 421, 271));
        sendLineEdit = new QLineEdit(server);
        sendLineEdit->setObjectName(QString::fromUtf8("sendLineEdit"));
        sendLineEdit->setGeometry(QRect(20, 300, 421, 81));
        sendLineEdit->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        listView = new QListView(server);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(450, 20, 256, 271));
        startBtn = new QPushButton(server);
        startBtn->setObjectName(QString::fromUtf8("startBtn"));
        startBtn->setGeometry(QRect(500, 400, 93, 28));
        endBtn = new QPushButton(server);
        endBtn->setObjectName(QString::fromUtf8("endBtn"));
        endBtn->setEnabled(false);
        endBtn->setGeometry(QRect(610, 400, 93, 28));
        linkLineEdit = new QLineEdit(server);
        linkLineEdit->setObjectName(QString::fromUtf8("linkLineEdit"));
        linkLineEdit->setEnabled(false);
        linkLineEdit->setGeometry(QRect(450, 350, 256, 31));
        label = new QLabel(server);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(450, 310, 241, 16));
        privateCheck = new QCheckBox(server);
        privateCheck->setObjectName(QString::fromUtf8("privateCheck"));
        privateCheck->setGeometry(QRect(30, 400, 91, 19));
        userBox = new QComboBox(server);
        userBox->setObjectName(QString::fromUtf8("userBox"));
        userBox->setGeometry(QRect(120, 400, 211, 22));
        sendBtn = new QPushButton(server);
        sendBtn->setObjectName(QString::fromUtf8("sendBtn"));
        sendBtn->setEnabled(false);
        sendBtn->setGeometry(QRect(350, 400, 93, 28));

        retranslateUi(server);

        QMetaObject::connectSlotsByName(server);
    } // setupUi

    void retranslateUi(QWidget *server)
    {
        server->setWindowTitle(QCoreApplication::translate("server", "\346\234\215\345\212\241\345\231\250", nullptr));
        startBtn->setText(QCoreApplication::translate("server", "\345\274\200\345\220\257", nullptr));
        endBtn->setText(QCoreApplication::translate("server", "\345\205\263\351\227\255", nullptr));
        linkLineEdit->setInputMask(QString());
        linkLineEdit->setText(QString());
        label->setText(QCoreApplication::translate("server", "\346\234\215\345\212\241\345\231\250\346\234\252\345\220\257\347\224\250", nullptr));
        privateCheck->setText(QCoreApplication::translate("server", "\345\215\225\347\213\254\345\217\221\351\200\201", nullptr));
        sendBtn->setText(QCoreApplication::translate("server", "\345\217\221\351\200\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class server: public Ui_server {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVER_H
