/********************************************************************************
** Form generated from reading UI file 'regist.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGIST_H
#define UI_REGIST_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_regist
{
public:
    QLabel *RigTItle;
    QLabel *pwdLabel;
    QLabel *pwdCFLabel;
    QLabel *queLabel;
    QLabel *aswLabel;
    QLineEdit *pwdLineE;
    QLineEdit *pwdCFLineE;
    QLineEdit *aswLineE;
    QComboBox *queBox;
    QPushButton *regBtn;
    QPushButton *rtnBtn;
    QLabel *pwdLabel_2;
    QLineEdit *userName;

    void setupUi(QWidget *regist)
    {
        if (regist->objectName().isEmpty())
            regist->setObjectName(QString::fromUtf8("regist"));
        regist->resize(587, 386);
        RigTItle = new QLabel(regist);
        RigTItle->setObjectName(QString::fromUtf8("RigTItle"));
        RigTItle->setGeometry(QRect(230, 10, 131, 41));
        QFont font;
        font.setPointSize(20);
        RigTItle->setFont(font);
        pwdLabel = new QLabel(regist);
        pwdLabel->setObjectName(QString::fromUtf8("pwdLabel"));
        pwdLabel->setGeometry(QRect(60, 105, 90, 30));
        QFont font1;
        font1.setPointSize(10);
        pwdLabel->setFont(font1);
        pwdLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        pwdCFLabel = new QLabel(regist);
        pwdCFLabel->setObjectName(QString::fromUtf8("pwdCFLabel"));
        pwdCFLabel->setGeometry(QRect(60, 160, 90, 30));
        pwdCFLabel->setFont(font1);
        pwdCFLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        queLabel = new QLabel(regist);
        queLabel->setObjectName(QString::fromUtf8("queLabel"));
        queLabel->setGeometry(QRect(60, 215, 90, 30));
        queLabel->setFont(font1);
        queLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        aswLabel = new QLabel(regist);
        aswLabel->setObjectName(QString::fromUtf8("aswLabel"));
        aswLabel->setGeometry(QRect(60, 270, 90, 30));
        aswLabel->setFont(font1);
        aswLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        pwdLineE = new QLineEdit(regist);
        pwdLineE->setObjectName(QString::fromUtf8("pwdLineE"));
        pwdLineE->setGeometry(QRect(180, 105, 350, 30));
        pwdLineE->setFont(font1);
        pwdLineE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        pwdCFLineE = new QLineEdit(regist);
        pwdCFLineE->setObjectName(QString::fromUtf8("pwdCFLineE"));
        pwdCFLineE->setGeometry(QRect(180, 160, 350, 30));
        pwdCFLineE->setFont(font1);
        pwdCFLineE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        aswLineE = new QLineEdit(regist);
        aswLineE->setObjectName(QString::fromUtf8("aswLineE"));
        aswLineE->setGeometry(QRect(180, 270, 350, 30));
        aswLineE->setFont(font1);
        aswLineE->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        queBox = new QComboBox(regist);
        queBox->setObjectName(QString::fromUtf8("queBox"));
        queBox->setGeometry(QRect(180, 215, 350, 30));
        queBox->setFont(font1);
        regBtn = new QPushButton(regist);
        regBtn->setObjectName(QString::fromUtf8("regBtn"));
        regBtn->setGeometry(QRect(120, 320, 100, 30));
        regBtn->setFont(font1);
        rtnBtn = new QPushButton(regist);
        rtnBtn->setObjectName(QString::fromUtf8("rtnBtn"));
        rtnBtn->setGeometry(QRect(360, 320, 100, 30));
        rtnBtn->setFont(font1);
        pwdLabel_2 = new QLabel(regist);
        pwdLabel_2->setObjectName(QString::fromUtf8("pwdLabel_2"));
        pwdLabel_2->setGeometry(QRect(60, 60, 90, 30));
        pwdLabel_2->setFont(font1);
        pwdLabel_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        userName = new QLineEdit(regist);
        userName->setObjectName(QString::fromUtf8("userName"));
        userName->setGeometry(QRect(180, 60, 350, 30));
        userName->setFont(font1);
        userName->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);

        retranslateUi(regist);

        QMetaObject::connectSlotsByName(regist);
    } // setupUi

    void retranslateUi(QWidget *regist)
    {
        regist->setWindowTitle(QCoreApplication::translate("regist", "\346\263\250\345\206\214\347\225\214\351\235\242", nullptr));
        RigTItle->setText(QCoreApplication::translate("regist", "\347\224\250\346\210\267\346\263\250\345\206\214", nullptr));
        pwdLabel->setText(QCoreApplication::translate("regist", "\345\257\206    \347\240\201\357\274\232", nullptr));
        pwdCFLabel->setText(QCoreApplication::translate("regist", "\347\241\256\350\256\244\345\257\206\347\240\201\357\274\232", nullptr));
        queLabel->setText(QCoreApplication::translate("regist", "\345\257\206\344\277\235\351\227\256\351\242\230\357\274\232", nullptr));
        aswLabel->setText(QCoreApplication::translate("regist", "\345\257\206\344\277\235\347\255\224\346\241\210\357\274\232", nullptr));
        regBtn->setText(QCoreApplication::translate("regist", "\346\263\250\345\206\214", nullptr));
        rtnBtn->setText(QCoreApplication::translate("regist", "\350\277\224\345\233\236", nullptr));
        pwdLabel_2->setText(QCoreApplication::translate("regist", "\347\224\250 \346\210\267 \345\220\215\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class regist: public Ui_regist {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGIST_H
